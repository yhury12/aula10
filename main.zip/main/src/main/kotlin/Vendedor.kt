class Vendedor {
    var nome: String? = null
    var idade: Byte? = null
    var cpf: String? = null
    var cliente: Cliente? = null



}