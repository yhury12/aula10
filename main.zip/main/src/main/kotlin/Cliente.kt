class Cliente {
    var nome: String? = null
    var cpf: String? = null
    var idade: Byte? = null
    var vendedor: Vendedor? = null


}