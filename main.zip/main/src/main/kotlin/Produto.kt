class Produto {
    var quantidade: String? = null
    var preco: String? = null
    var codigo: String? = null
    var fornecedor: Fornecedor? = null
    var vendedor: Vendedor? = null
    var cliente: Cliente? = null

}