class Transportadora {
    var cnpj: String? = null
    var nome: String? = null
    var vendedor: Vendedor? = null
    var produto: Produto? = null


}