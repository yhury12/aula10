class Venda {
    var nomeDoProduto: String? = null
    var quantidade: Int? = null
    var cliente: Cliente? = null
    var vendedor: Vendedor? = null

}