class Fornecedor {
    var nome: String? = null
    var cpf: String? = null
    var produto: Produto? = null
    var vendedor: Vendedor? = null

}