
rootProject.name = "geometria"

