package model

data class Music(
    var title: String,
    var duration: Short,
    val musicGender: MusicGender.MusicGender,
    var yearOfRealease: Short,
    var composer: String,
    var record: String,
    val album: String,

    )
