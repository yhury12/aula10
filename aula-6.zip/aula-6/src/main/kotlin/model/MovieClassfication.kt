package model

enum class MovieClassfication {
    LIVRE,DOZE,QUATORZE,DEZESEIS,DEZOITO
}