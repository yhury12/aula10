package model

class MusicGender {

    enum class MusicGender {
        SERTANEJO,ROCK,POP,REGGAE,CLASSICA
    }
}