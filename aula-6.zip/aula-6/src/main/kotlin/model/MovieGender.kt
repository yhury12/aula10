package model

enum class MovieGender {
    TERROR,ACAO,AVENTURA,FICCAOCIENTIFCA
}